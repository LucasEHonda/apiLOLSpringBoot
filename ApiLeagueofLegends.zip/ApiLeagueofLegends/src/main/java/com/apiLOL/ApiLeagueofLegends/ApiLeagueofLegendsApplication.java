package com.apiLOL.ApiLeagueofLegends;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiLeagueofLegendsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiLeagueofLegendsApplication.class, args);
	}

}
