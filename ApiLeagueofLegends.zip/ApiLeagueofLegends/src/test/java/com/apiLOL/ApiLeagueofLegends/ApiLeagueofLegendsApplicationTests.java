package com.apiLOL.ApiLeagueofLegends;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiLeagueofLegendsApplicationTests {

	@Test
	void contextLoads() {
	}

}
